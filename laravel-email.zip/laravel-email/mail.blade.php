<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h1>Thanks for Submitting Email {{ $data['name'] }}</h1>
</body>
</html>

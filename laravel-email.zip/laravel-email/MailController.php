<?php

namespace App\Http\Controllers;
use App\User;
use App\Mail\Mailtrap;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class MailController extends Controller
{
	
	//public function index(){
    //Mail::to("decentomais90@gmail.com")->send(new Mailtrap());

    
    public function index(){
    	return view("send_email");
    }

    function send(Request $request){
    
    	$this->validate($request,[
    		'name' => 'required',
    		 'email' => 'required|email',
    		 'message' => 'required'

    	]);

    	//User::create($re);

    	$data =array(
          'name' => $request->name,
          'message' => $request->message
    	);
         
         Mail::to("decentomais90@gmail.com")->send(new Mailtrap($data));
         return back()->with('success','Thanks For Contacting Us!');
    }


}


